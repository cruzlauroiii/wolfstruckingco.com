// Single JS interop module loaded by SharedUI components. Wraps Leaflet, IndexedDB, and the
// Cloudflare worker fetch under a stable API the C# side calls via IJSRuntime.
// No third-party JS — Leaflet itself is loaded via <script> in index.html and is the only dep.

(function () {
  if (window.WolfsInterop) return;
  const w = {};

  const WORKER = 'https://wolfstruckingco.nbth.workers.dev';

  // ─── Map (Leaflet) ─────────────────────────────────────────────────────
  const maps = new Map();
  w.mapInit = function (id, lat, lng, zoom, theme) {
    if (!window.L) throw new Error('Leaflet not loaded');
    if (maps.has(id)) { try { maps.get(id).remove(); } catch (_) {} maps.delete(id); }
    const m = L.map(id, { zoomControl: false, maxZoom: 19 }).setView([lat, lng], zoom);
    L.control.zoom({ position: 'bottomleft' }).addTo(m);
    const tileUrl = theme === 'dark'
      ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
      : 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png';
    L.tileLayer(tileUrl, { maxZoom: 19, subdomains: 'abcd' }).addTo(m);
    maps.set(id, m);
    return true;
  };
  w.mapSetView = function (id, lat, lng, zoom) { const m = maps.get(id); if (m) m.setView([lat, lng], zoom); };
  w.mapPanBy = function (id, dx, dy) { const m = maps.get(id); if (m) m.panBy([dx, dy], { animate: false }); };
  w.mapDestroy = function (id) { const m = maps.get(id); if (m) { m.remove(); maps.delete(id); } };
  w.mapAddPin = function (id, lat, lng, color, label) {
    const m = maps.get(id); if (!m) return null;
    const html = '<div style="width:30px;height:30px;border-radius:50%;background:' + (color || '#9a3a10') +
                 ';border:3px solid #ffffff;box-shadow:0 0 0 1px #cbd5e1;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800">' + (label || '') + '</div>';
    return L.marker([lat, lng], { icon: L.divIcon({ className: '', html, iconSize: [30, 30], iconAnchor: [15, 15] }) }).addTo(m);
  };
  w.mapDrawRoute = function (id, coords, color) {
    const m = maps.get(id); if (!m || !coords || coords.length < 2) return;
    const line = L.polyline(coords, { color: color || '#3b82f6', weight: 6, opacity: .9 }).addTo(m);
    try { m.fitBounds(line.getBounds(), { padding: [40, 40] }); } catch (_) {}
    return line;
  };

  // ─── IndexedDB-backed wolfs_* store with Cloudflare R2 sync ──────────
  // Mirrors the existing /wolfstruckingco.com/db.js so existing R2 records keep working.
  function dbOpen() {
    return new Promise((res, rej) => {
      const r = indexedDB.open('wolfs', 1);
      r.onupgradeneeded = () => {
        const d = r.result;
        ['users','workers','jobs','timesheets','applicants','listings','purchases','badges','roles','customers','audit'].forEach(s => {
          if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { keyPath: 'id' });
        });
      };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
  }
  async function dbAll(store) {
    const db = await dbOpen();
    return await new Promise((res, rej) => {
      const tx = db.transaction(store, 'readonly');
      const req = tx.objectStore(store).getAll();
      req.onsuccess = () => res(req.result || []);
      req.onerror = () => rej(req.error);
    });
  }
  async function dbPut(store, val) {
    const db = await dbOpen();
    return await new Promise((res, rej) => {
      const tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).put(val);
      tx.oncomplete = () => res(true);
      tx.onerror = () => rej(tx.error);
    });
  }
  async function dbGet(store, id) {
    const db = await dbOpen();
    return await new Promise((res, rej) => {
      const tx = db.transaction(store, 'readonly');
      const req = tx.objectStore(store).get(id);
      req.onsuccess = () => res(req.result || null);
      req.onerror = () => rej(req.error);
    });
  }
  w.dbAll = dbAll; w.dbPut = dbPut; w.dbGet = dbGet;
  w.dbAllJson = async function (store) { return JSON.stringify(await dbAll(store)); };

  // ─── Chat call button (📞) ────────────────────────────────────────────
  // Used by Sell/Applicant/Dispatcher chat rows. Two paths:
  //  1. Cloudflare Realtime via worker /voice (production): WebRTC peer
  //     connection, audio streamed both ways through the worker. Anthropic
  //     key never leaves the worker (item #8).
  //  2. Local sidecar fallback (dev): MediaRecorder → /stt → text in input.
  // Auto-degrades from (1) → (2) → alert if neither is reachable.
  w.WolfsCall = async function (btn) {
    var orig = btn ? btn.textContent : '';
    if (btn) { btn.textContent = '⏺'; btn.dataset.recording = '1'; btn.disabled = true; }
    function reset () { if (btn) { btn.textContent = orig; delete btn.dataset.recording; btn.disabled = false; } }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { alert('🎤 Browser does not support getUserMedia.'); reset(); return; }
    // Path 1: Cloudflare Realtime WebRTC.
    try {
      var pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.cloudflare.com:3478' }] });
      var stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(function (t) { pc.addTrack(t, stream); });
      pc.addTransceiver('audio', { direction: 'recvonly' });
      var offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      var sess = localStorage.getItem('wolfs_session') || '';
      var role = localStorage.getItem('wolfs_role') || 'client';
      var resp = await fetch(WORKER + '/voice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Wolfs-Session': sess, 'X-Wolfs-Role': role },
        body: JSON.stringify({ sdp: offer.sdp, type: 'offer' }),
      });
      if (resp.ok) {
        var answer = await resp.json();
        await pc.setRemoteDescription({ sdp: answer.sdp, type: 'answer' });
        pc.ontrack = function (ev) {
          var audio = new Audio();
          audio.srcObject = ev.streams[0];
          audio.play().catch(function () {});
        };
        window.WolfsCallActive = pc;
        if (btn) {
          btn.onclick = function () { try { pc.close(); } catch (e) {} stream.getTracks().forEach(function (t) { t.stop(); }); window.WolfsCallActive = null; reset(); btn.onclick = null; };
          btn.title = 'End call';
        }
        return;
      }
      try { pc.close(); } catch (e) {}
      stream.getTracks().forEach(function (t) { t.stop(); });
      // fall through to path 2
    } catch (e) { /* fall through */ }
    // Path 2: local sidecar transcription fallback.
    var bridge = window.WolfsChatVoice;
    if (!bridge) { alert('🎤 Realtime upstream unavailable and no local voice sidecar. Run worker/voice-sidecar.cs locally for STT fallback.'); reset(); return; }
    var ok = false;
    try { ok = await bridge.start(); } catch (e) { ok = false; }
    if (!ok) { alert('🎤 Realtime + sidecar both unavailable. Configure worker REALTIME_APP_ID/REALTIME_APP_TOKEN secrets or start the local sidecar.'); reset(); return; }
    setTimeout(async function () {
      var text = '';
      try { text = await bridge.stop(); } catch (e) {}
      reset();
      if (text) {
        var row = btn && btn.parentElement ? btn.parentElement : null;
        var inp = row ? row.querySelector('input[type="text"]') : null;
        if (inp) { inp.value = text; inp.dispatchEvent(new Event('input', { bubbles: true })); }
        window.dispatchEvent(new CustomEvent('wolfs-call-transcript', { detail: { text: text } }));
      }
    }, 8000);
  };
  w.chatReply = async function (system, history, maxTokens) {
    var sess = localStorage.getItem('wolfs_session') || '';
    var role = localStorage.getItem('wolfs_role') || 'client';
    var resp = await fetch(WORKER + '/ai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Wolfs-Session': sess, 'X-Wolfs-Role': role },
      body: JSON.stringify({ messages: history, system: system, max_tokens: maxTokens || 256 }),
    });
    var data = await resp.json().catch(function () { return null; });
    return (data && data.text) || (data && data.error) || 'Sorry, no reply.';
  };
  w.startCall = async function (role, subject) {
    if (!navigator.mediaDevices) return 'mic unavailable';
    try {
      var pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.cloudflare.com:3478' }] });
      var stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach(function (t) { pc.addTrack(t, stream); });
      pc.addTransceiver('audio', { direction: 'recvonly' });
      var offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      var sess = localStorage.getItem('wolfs_session') || '';
      var resp = await fetch(WORKER + '/voice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Wolfs-Session': sess, 'X-Wolfs-Role': role || 'client' },
        body: JSON.stringify({ sdp: offer.sdp, type: 'offer', subject: subject || '' }),
      });
      if (!resp.ok) {
        try { pc.close(); } catch (e) {}
        stream.getTracks().forEach(function (t) { t.stop(); });
        var j = await resp.json().catch(function () { return null; });
        return 'realtime unavailable: ' + ((j && j.error) || resp.status);
      }
      var answer = await resp.json();
      await pc.setRemoteDescription({ sdp: answer.sdp, type: 'answer' });
      pc.ontrack = function (ev) { var a = new Audio(); a.srcObject = ev.streams[0]; a.play().catch(function () {}); };
      window.__wolfsCallPc = pc; window.__wolfsCallStream = stream;
      return 'connected';
    } catch (e) { return 'error: ' + e.message; }
  };
  w.endCall = function () {
    try { if (window.__wolfsCallPc) window.__wolfsCallPc.close(); } catch (e) {}
    try { if (window.__wolfsCallStream) window.__wolfsCallStream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    window.__wolfsCallPc = null; window.__wolfsCallStream = null;
  };
  w.themeCycle = function () {
    var cur = localStorage.getItem('wolfs_theme') || 'auto';
    var next = cur === 'auto' ? 'dark' : (cur === 'dark' ? 'light' : 'auto');
    try {
      localStorage.setItem('wolfs_theme', next);
      document.documentElement.setAttribute('data-theme', next === 'auto' ? '' : next);
    } catch (e) {}
    return next;
  };
  w.ssoLogin = function (provider) {
    var p = (provider || 'demo').toLowerCase();
    try {
      localStorage.setItem('wolfs_session', 'sso-' + p + '-' + Date.now());
      localStorage.setItem('wolfs_role', 'user');
      localStorage.setItem('wolfs_email', 'demo@' + p + '.example');
    } catch (e) {}
    var base = location.pathname.replace(/Login\/?$/, '');
    location.href = base + 'Marketplace/';
  };

  // ─── Cloudflare worker calls (sign in / sign up / chat / loc / buy) ──
  w.workerPost = async function (path, body, headers) {
    const r = await fetch(WORKER + path, {
      method: 'POST',
      headers: Object.assign({ 'Content-Type': 'application/json' }, headers || {}),
      body: typeof body === 'string' ? body : JSON.stringify(body || {}),
    });
    const txt = await r.text();
    return { ok: r.ok, status: r.status, body: txt };
  };
  w.workerGet = async function (path) {
    const r = await fetch(WORKER + path);
    return { ok: r.ok, status: r.status, body: await r.text() };
  };

  // ─── Theme ────────────────────────────────────────────────────────────
  w.themeRead = function () { return localStorage.getItem('wolfs_theme') || 'auto'; };
  w.themeWrite = function (v) { try { localStorage.setItem('wolfs_theme', v); document.documentElement.setAttribute('data-theme', v === 'auto' ? '' : v); } catch (_) {} };
  w.themeResolved = function () {
    const t = w.themeRead();
    if (t === 'auto') return matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    return t;
  };

  // ─── Auth (localStorage-backed, same keys as the static site) ────────
  w.authGet = function () {
    return {
      role: (localStorage.getItem('wolfs_role') || '').toLowerCase() || null,
      email: localStorage.getItem('wolfs_email') || null,
      sess:  localStorage.getItem('wolfs_session') || null,
    };
  };
  w.authSet = function (role, email, sess) {
    if (role) localStorage.setItem('wolfs_role', role); else localStorage.removeItem('wolfs_role');
    if (email) localStorage.setItem('wolfs_email', email); else localStorage.removeItem('wolfs_email');
    if (sess) localStorage.setItem('wolfs_session', sess); else localStorage.removeItem('wolfs_session');
  };
  w.authClear = function () { ['wolfs_role','wolfs_email','wolfs_session'].forEach(k => localStorage.removeItem(k)); };

  window.WolfsInterop = w;
})();
